public class main {



    public static void main(String[] args) {


       CRUDStudent crudStudent=new CRUDStudent();
       crudStudent.start();



    }
    /*
    * 1 Spring IOC ConTainer Nma?
    *
    * Spring IOC Container Abyektlarni dastur boshlanganda bir joyga saqlab qoyadi
    * yani containeri ichiga bean qilib saqlab qoyadi,
    * conteynirdan qachon abyekt chaqirilganda conteynirdan olib beradi
    * conteynirdagi abyektlar Bean dib ataladi
    *
    *
    *
    * Dependency Injection
    *
    * dependency Injection deganda boglanishi chunaman
    * yani masalan abyektni boshqa bir abyektga boglanishi Injection
    *
    *
    *
    *
    *
    * */

}
